﻿using BuggyCarsRating.Tests.Models;

namespace BuggyCarsRating.Tests.Contexts
{
    public class ConfigurationContext
    {
        public ConfigurationModel Configuration { get; set; }
    }
}
