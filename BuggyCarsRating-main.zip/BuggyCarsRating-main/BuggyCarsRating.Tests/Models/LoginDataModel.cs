﻿namespace BuggyCarsRating.Tests.Models
{
    public class LoginDataModel
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
