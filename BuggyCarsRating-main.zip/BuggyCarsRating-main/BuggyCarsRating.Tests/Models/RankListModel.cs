﻿namespace BuggyCarsRating.Tests.Models
{
    public class RankListModel
    {
        public int Rank { get; set; }
    }
}
